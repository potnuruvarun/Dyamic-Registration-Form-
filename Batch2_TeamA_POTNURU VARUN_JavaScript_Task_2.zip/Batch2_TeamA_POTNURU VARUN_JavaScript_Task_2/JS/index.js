let numRows =  2;
function addRow() {
  var container = document.getElementById("edu-details");
  
  var newRow = document.createElement("div");
  newRow.innerHTML = `    
  <div class="container-fluid">
  
        <div class="row d-flex">
          <div class="col"><input class="form-control" type="text" placeholder="Enter your Degree" id="degree${numRows}" /><span class="demo" id="deg${numRows}"></span></div>
          <div class="col"><input class="form-control" type="text" placeholder="Enter your College"  id="college${numRows}"/><span class="demo" id="col${numRows}"></span></div>
          <div class="col"><input class="form-control" type="date" placeholder="starts from" id="start${numRows}" /><span class="demo" id="sta${numRows}"></span></div>
          <div class="col"><input class="form-control" type="date" placeholder="ending" id="end${numRows}" /><span class="demo" id="endd${numRows}"></span></div>
          <div class="col"><input class="form-control" type="number" placeholder="Backlogs" id="backlog${numRows}" /><span class="demo" id="back${numRows}"></span></div>
          <div class="col"><input class="form-control" type="number" placeholder="percentage" id="percentage${numRows}" /><span  class="demo" id="per${numRows}"></span></div>
          <div class="col"><button class="btn btn-danger" onclick="deleteRow(this)">Delete</button></div>
        </div>    
 </div> 
    `;
  container.appendChild(newRow);
  numRows++;
}

function deleteRow(e) {
  const row = e.parentNode.parentNode.remove();
  numRows--
}

function submitForm() {
  var first = document.getElementById("firstName").value;
  var middle = document.getElementById("MiddName").value;
  var last = document.getElementById("lastName").value;
  var date = document.getElementById("date-of-birth").value;
  var mails = document.getElementById("email").value;
  var phone = document.getElementById("phone").value;
  var address = document.getElementById("Address").value;
 var Detailsarray=[];
  var StudentDetails = {
    first1: first,
    middle1: middle,
    last1: last,
    date1: date,
    mails1: mails,
    phone1: phone,
    address1: address,
    education: Detailsarray,
  };
  var letter = /^[0-9]+$/;
  var numbers = /^[a-z]+$/;
  var mail = /^([a-z0-9]+)@([a-zA-Z0-9]+).([a-zA-Z0-9])+$/;
  var error = false;
  var errorDisplayed = false;

  if (letter.test(first) || first == "") {
    document.getElementById("demo").innerHTML = "Enter your First Name";

    error = true;
  } else {
    document.getElementById("demo").innerHTML = "";
  }

  if (letter.test(last) || last == "") {
    document.getElementById("demo2").innerHTML = "Enter your Last Name";

    error = true;
  } else {
    document.getElementById("demo2").innerHTML = "";
  }

  if (date == "") {
    document.getElementById("demo3").innerHTML = "Enter your Date Of Birth";
    error = true;
  } else {
    document.getElementById("demo3").innerHTML = "";
  }

  if (mail.test(mails) || mails == "") {
    document.getElementById("demo4").innerHTML = "Enter a valid Email Address";
    error = true;
  } else {
    document.getElementById("demo4").innerHTML = "";
  }

  if (numbers.test(phone) || phone == "") {
    document.getElementById("demo5").innerHTML = "Enter a valid Phone Number";

    error = true;
  } else {
    document.getElementById("demo5").innerHTML = "";
  }

  if (address == "") {
    document.getElementById("demo6").innerHTML = "Enter your Address";

    error = true;
  } else {
    document.getElementById("demo6").innerHTML = "";
  }

  document.querySelectorAll("#edu-details > div");
  for (var i = 0; i <numRows; i++) {
    var degrees = document.getElementById(`degree${i}`).value;
    var colleges = document.getElementById(`college${i}`).value;
    var starts = document.getElementById(`start${i}`).value;
    var enddate = document.getElementById(`end${i }`).value;
    var Backlogs = document.getElementById(`backlog${i}`).value;
    var percentages = document.getElementById(`percentage${i}`).value;

    if (degrees == "") {
      document.getElementById(`deg${i}`).innerHTML = "Enter your degree";

      error = true;
    } else {
      document.getElementById(`deg${i}`).innerHTML = "";
    }
    if (letter.test(colleges) || colleges == "") {
      document.getElementById(`col${i}`).innerHTML = "Enter your College";

      error = true;
    } else {
      document.getElementById(`col${i}`).innerHTML = "";
    }
    if (starts == "") {
      document.getElementById(`sta${i}`).innerHTML = "Enter your Date of join";

      error = true;
    } else {
      document.getElementById(`sta${i}`).innerHTML = "";
    }
    if (enddate == "") {
      document.getElementById(`endd${i}`).innerHTML =
        "Enter your Pass Out Year";

      error = true;
    } else {
      document.getElementById(`endd${i}`).innerHTML = "";
    }
    if (Backlogs == "") {
      document.getElementById(`back${i}`).innerHTML = "Enter your Backlogs";

      error = true;
    } else {
      document.getElementById(`back${i}`).innerHTML = "";
    }
    if (percentages == "") {
      document.getElementById(`per${i}`).innerHTML = "Enter your Percentahe";

      error = true;
    } else {
      document.getElementById(`per${i}`).innerHTML = "";
    }

    var educationDetails = {
      degree: degrees,
      college: colleges,
      start: starts,
      end: enddate,
      backlogs: Backlogs,
      percentage: percentages,
    };
    Detailsarray.push(educationDetails);
  }
  if (!error) {
    console.log(StudentDetails);
    
  }
  if (!error) {
    document.getElementById("demo").innerHTML = "";
  }
}
